package strategy;

public interface IPaymentStrategy {

    void pay(int amount);

}
